﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseDown : MonoBehaviour 
{
	internal delegate void OnMouseClick ();
	internal  OnMouseClick onMouseClick;

	private void OnMouseDown()
	{
		if (onMouseClick != null)
			onMouseClick ();
	}
}
