﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileID : MonoBehaviour 
{
	[SerializeField]internal string tileID;
}
