﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class CharacterAnim : MonoBehaviour 
{
	
	private Animator orcAnim;

	// Use this for initialization
	void Start () 
	{
		orcAnim = GetComponent<Animator> ();
		GetComponent<MouseDown> ().onMouseClick+=PlayRandomAnimation;
		DontDestroyOnLoad (this.gameObject);

	}
	


	public void PlayRandomAnimation()
	{
		orcAnim.SetInteger("Anim", Random.Range(1,5));
		//orcAnim.SetInteger("Anim", 0);
		CancelInvoke("PlayIdle");
		Invoke("PlayIdle",0.2f);
	}
	void PlayIdle()
	{
		orcAnim.SetInteger("Anim", 0);
	}


}
