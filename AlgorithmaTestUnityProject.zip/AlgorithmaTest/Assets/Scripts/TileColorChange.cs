﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TileColorChange : MonoBehaviour
{
	[SerializeField]private Image[] tiles;
	WaitForSeconds waitForOneSeconds = new WaitForSeconds (1);


	
	public void StratChangeTileColor()
	{
		print ("change color called");
		for (int i = 0; i < tiles.Length; i++) 
		{
			tiles [i].GetComponent<Button> ().interactable = false;
		}
		StartCoroutine ("_ChangeTilesColor");
	}
	private IEnumerator _ChangeTilesColor()
	{
		for(int i=0;i<tiles.Length;i++)
		{
			tiles [i].color = Color.green;
			yield return waitForOneSeconds;
		}
		GameManager.instance.OnTileColorChangeComplete ();
	}
}
