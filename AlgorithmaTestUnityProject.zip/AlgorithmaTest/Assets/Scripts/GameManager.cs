﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour 
{
	internal static GameManager instance;
	// Use this for initialization
	void Start () 
	{
		if (instance == null)
			instance = this;
		else
		{
			Destroy (gameObject);// to prevent multiple copy of manager class
		}
			
		DontDestroyOnLoad(gameObject);
	}
	
	internal void OnTileColorChangeComplete()
	{
		SceneManager.LoadScene ("Scene2");
	}
}
