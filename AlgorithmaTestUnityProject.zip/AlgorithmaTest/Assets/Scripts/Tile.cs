﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tile :TileID 
{
	[SerializeField] private Camera tileCamera;
	[SerializeField] private ParticleSystem particcelEffect;
	private Vector3 startPos;
	private bool isTriggerTile=false;
	private TilesController tileController;


	private void Start()
	{
		startPos = transform.position;
		tileController = FindObjectOfType<TilesController> ();
	}
	void OnMouseDrag()
	{
		
		{
			Vector3 pos = tileCamera.ScreenToWorldPoint (Input.mousePosition);
			transform.position = new Vector3 (pos.x,pos.y,transform.position.z);

		}

	}

	void OnMouseDown()
	{
		GetComponent<Image> ().enabled = true;
	}

	void OnMouseUp()
	{
		if (!isTriggerTile)
			transform.position = startPos;	
	}

	private void OnTriggerEnter(Collider other)
	{
		isTriggerTile = true;
	}

	private void OnTriggerExit(Collider other)
	{
		isTriggerTile=false;
	}

	private void OnTriggerStay(Collider other)
	{
		if (Input.GetMouseButtonUp (0))
		{
			isTriggerTile=false;
			transform.position = startPos;

			if(tileID == other.GetComponent<TileID> ().tileID)
			{
				other.gameObject.SetActive(false);
				particcelEffect.gameObject.transform.position = other.gameObject.transform.position;
				particcelEffect.Play();
				tileController.OnTileDestroy ();
			}

				
		}
				
	}


}
