﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TilesController : MonoBehaviour 
{
	[SerializeField]private GameObject[] fixedTiles; // tiles which are fixed and will be picked to drag
	[SerializeField]private GameObject[] dragableTiles; //tile which are dragable dragable

	private int destroyedTileCount=0;

	internal void OnTileDestroy()
	{
		destroyedTileCount++;
		if(destroyedTileCount==fixedTiles.Length)
		{
			print ("complete");
			for(int i=0;i<fixedTiles.Length;i++)
			{
				fixedTiles [i].SetActive (false);
			}
			CancelInvoke("LoadAsseBundleImage");
			Invoke("LoadAsseBundleImage",0.5f);
		}
	}

	void LoadAsseBundleImage()
	{
		FindObjectOfType<AssetDownloader> ().Load ("Ref");
	}
}
