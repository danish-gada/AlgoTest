﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UiManager : MonoBehaviour
{
	internal static UiManager instance;
	[SerializeField] private GameObject startPnl; // game start panel

	private void Start()
	{
		if (instance == null)
			instance = this;
		else
			Destroy (this);
		
	}

	public void StartButton()
	{
		startPnl.SetActive (false);
	}
}
