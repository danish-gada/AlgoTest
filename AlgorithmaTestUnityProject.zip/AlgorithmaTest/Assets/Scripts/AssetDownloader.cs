﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class AssetDownloader : MonoBehaviour 
{
	public string url;
	public SpriteRenderer refI;// sprite renderer to show the loaded sprite
	public Text loadingText;



	private IEnumerator LoadBundle(string assetName) 
	{
	    while (!Caching.ready) 
	    {
			yield return null;
	    }

	    //start Loading
	    WWW www = WWW.LoadFromCacheOrDownload (url, 0);
	    yield return www;

	    //Load the downloaded bundle
	    AssetBundle bundle = www.assetBundle;
	    //Load an asset from the loaded bundle
		AssetBundleRequest bundleRequest = bundle.LoadAssetAsync (assetName, typeof(Sprite));
	    yield return bundleRequest;
		Sprite obj = bundleRequest.asset as Sprite;
		refI.sprite = obj;
		loadingText.text = "";
        bundle.Unload(false);
        www.Dispose();
	}

	public void Load(string assetName)
	{
		loadingText.text = "Loading...";
		StartCoroutine(LoadBundle(assetName));		
	}
}
