﻿using UnityEngine;


using System.Collections;


using System.Collections.Generic;





public class MG_Pool : MonoBehaviour


{





	GameObject lastReturned;


	internal void CreatePool(GameObject Obj,int size,List<GameObject> poolList)


	{


		//		Debug.Log ("pool class method called");


		for(int i=0;i<size;i++)


		{


			GameObject tempObj=(GameObject) Instantiate(Obj);


			tempObj.SetActive(false);


			poolList.Add(tempObj);





		}


	}


	//


	internal GameObject GetPoolObject(List<GameObject> pool)


	{


		for(int i=0;i<pool.Count;i++)


		{


			if(!pool[i].activeInHierarchy && lastReturned!=pool[i])


			{ 


				lastReturned = pool [i];


				return  pool[i];


			}


		}





		return null;


	}


}


